/*
 * Class: CMSC203 
 * Instructor: Khandan Monshi
 * Description: CryptoManager Class --> contains methods that will determine 
 *              if a determined string is in bounds and encrypt it or decrypt depending on what the user wants to do
 * Due: 10/16/2023
 * Platform/compiler: Eclipse IDE
 * I pledge that I have completed the programming  assignment independently. 
*  I have not copied the code from a student or any source. 
*  I have not given my code to any student.
*  Print your Name here: Felipe da Rocha de Brito Machado
*/

/**
 * This is a utility class that encrypts and decrypts a phrase using two different approaches. 
 * The first approach is the Caesar Cipher, a simple substitution cipher where characters in a 
 * message are replaced by a substitute character. The second approach, due to Giovan Battista Bellaso, 
 * uses a key word, where each character in the word specifies the offset for the corresponding character 
 * in the message, with the key word wrapping around as needed.
 * 
 * @author Farnaz Eivazi
 * @version 7162022
 */
public class CryptoManager {

    private static final char LOWER_RANGE = ' ';
    private static final char UPPER_RANGE = '_';
    private static final int RANGE = UPPER_RANGE - LOWER_RANGE + 1;

    /**
     * This method determines if a string is within the allowable bounds of ASCII
     * codes according to the LOWER_RANGE and UPPER_RANGE characters
     * 
     * @param plainText a string to be encrypted, if it is within the allowable
     *                  bounds
     * @return true if all characters are within the allowable bounds, false if
     *         any character is outside
     */
    public static boolean isStringInBounds(String plainText) {
        for (int i = 0; i < plainText.length(); i++) { // check if each character is acceptable for our bounds and return false if not
            char temp = plainText.charAt(i);
            if (temp < LOWER_RANGE || temp > UPPER_RANGE) {
                return false;
            }
        }
        return true;
    }

    /**
     * Encrypts a string according to the Caesar Cipher. The integer key specifies
     * an offset, and each character in plainText is replaced by the character
     * offset away from it.
     * 
     * @param plainText an uppercase string to be encrypted.
     * @param key       an integer that specifies the offset of each character
     * @return the encrypted string
     */
    public static String caesarEncryption(String plainText, int key) {
        if (!isStringInBounds(plainText))
            return "The selected string is not in bounds, Try again."; // return this message if not in bounds

        StringBuilder encryptedText = new StringBuilder();
        for (int i = 0; i < plainText.length(); i++) {
            char temp = plainText.charAt(i);
            int shift = (int) (temp + key); // shift will have the value of each char + our chosen key
            while (shift < LOWER_RANGE || shift > UPPER_RANGE) { // as long as shift is outside our RANGE, sum RANGE to it or subtract RANGE from it
                if (shift < LOWER_RANGE)
                    shift += RANGE;
                else if (shift > UPPER_RANGE)
                    shift -= RANGE;
            }
            encryptedText.append((char) shift);
        }
        return encryptedText.toString();
    }

    /**
     * Encrypts a string according to the Bellaso Cipher. Each character in
     * plainText is offset according to the ASCII value of the corresponding
     * character in bellasoStr, which is repeated to correspond to the length of
     * plainText.
     * 
     * @param plainText  an uppercase string to be encrypted.
     * @param bellasoStr an uppercase string that specifies the offsets,
     *                   character by character.
     * @return the encrypted string
     */
    public static String bellasoEncryption(String plainText, String bellasoStr) {
        String encryptedText = "";

        for (int i = 0; i < plainText.length(); i++) {
            char temp = plainText.charAt(i); // iterate through the string 
            char decryptedChar = bellasoStr.charAt(i % bellasoStr.length()); // get the belasso char using given formula 
            int shift = (int) (temp + decryptedChar);
            while (shift < LOWER_RANGE || shift > UPPER_RANGE) { // reduce or sum up range to shift until it gets into our RANGE
                if (shift < LOWER_RANGE)
                    shift += RANGE;
                else if (shift > UPPER_RANGE)
                    shift -= RANGE;
            }
            encryptedText += (char)shift; // concatenate every character to form the encrypted text
        }

        return encryptedText.toString(); // return the encrypted string
    }

    /**
     * Decrypts a string according to the Caesar Cipher. The integer key specifies
     * an offset, and each character in encryptedText is replaced by the character
     * offset characters before it. This is the inverse of the encryptCaesar
     * method.
     * 
     * @param encryptedText an encrypted string to be decrypted.
     * @param key           an integer that specifies the offset of each character
     * @return the plain text string
     */
    public static String caesarDecryption(String encryptedText, int key) {
        String decryptedText = "";
        for (int i = 0; i < encryptedText.length(); i++) {
            char temp = encryptedText.charAt(i);
            int shift = (int) (temp - key);
            while (shift < LOWER_RANGE || shift > UPPER_RANGE) {
                if (shift > UPPER_RANGE)
                    shift -= RANGE;
                if (shift < LOWER_RANGE) {
                    shift += RANGE;
                }
            }
            decryptedText += (char)shift;
        }

        return decryptedText.toString();
    }

    /**
     * Decrypts a string according to the Bellaso Cipher. Each character in
     * encryptedText is replaced by the character corresponding to the character in
     * bellasoStr, which is repeated to correspond to the length of plainText. This
     * is the inverse of the encryptBellaso method.
     * 
     * @param encryptedText an uppercase string to be encrypted.
     * @param bellasoStr    an uppercase string that specifies the offsets,
     *                      character by character.
     * @return the decrypted string
     */
    public static String bellasoDecryption(String encryptedText, String bellasoStr) {
        String decryptedText = "";

        for (int i = 0; i < encryptedText.length(); i++) {
            char temp = encryptedText.charAt(i);
            char bellasoChar = bellasoStr.charAt(i % bellasoStr.length()); // create a pattern for encrypting and decrypting if KEY is bigger than TEXT
            int shift = (int) (temp - bellasoChar);
            while (shift < LOWER_RANGE || shift > UPPER_RANGE) { // follow the same logic of caesar decryption. reduce or increase if out of range 
                if (shift > UPPER_RANGE)
                    shift -= RANGE;
                if (shift < LOWER_RANGE) {
                    shift += RANGE;
                }
            }
            decryptedText += (char)shift; // concatenate the shifted characters and form a string 
        }

        return decryptedText.toString();
    }
}
